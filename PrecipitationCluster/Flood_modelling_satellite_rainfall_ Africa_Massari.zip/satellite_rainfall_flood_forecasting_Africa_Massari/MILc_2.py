# -*- coding: utf-8 -*-
"""
Created on Tue Mar  8 23:20:11 2016

@author: christian_massari, Luca Brocca
Dec 2020: modified output to obtain KGE (removed perf class)
"""

import numpy as np
import scipy as sc
from scipy import misc
import pandas as pd
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
import sys
from scipy.stats import pearsonr
from hydroeval import *

#%%
def IUH_comp(gamma,Ab,dt,deltaT):
    """
    %% % -------------------------------------------------------------------------------
    #% Calculation of Geomorphological Instantaneous Unit Hydrograph
    #% ---------------------------------------------------------------------------------
    """
    Lag=(gamma*1.19*Ab**0.33)/deltaT
    hp=0.8/Lag
    data=np.loadtxt('IUH.txt')
    t=data[:,0]*Lag
    IUH_0=data[:,1]*hp
    ti=np.arange(0,max(t),dt)
    IUH=np.interp(ti,t,IUH_0)
    return IUH
#%%

def IUH_NASH(n,gamma,Ab,dt,deltaT):

    """
    % -------------------------------------------------------------------------------
    % Calculation of Nash Instantaneous Unit Hydrograph
    % -------------------------------------------------------------------------------
    """
    K=(gamma*1.19*Ab**.33)/deltaT
    time=np.arange(0,100,dt)
    IUH=((time/K)**(n-1)*np.exp(-time/K)/sc.special.factorial(n-1)/K)
    return IUH


#%% Read data from file
# -*- coding: utf-8 -*-
"""
Created on Thu Mar 10 13:26:54 2016
@author: christian_massari
"""

def MILC(name,data_input,PAR,Ab,Wobs=[],K=0,fig=0):


    PIO=data_input['P']
    TEMPER=data_input['T']
    Qobs=data_input['Q']
    N=len(Qobs)
    data_input.index=pd.to_datetime(data_input.index)


    MESE = data_input.index.month.values

    #% READ MODEL PARAMETERS

    W_p       = PAR[0] # initial conditions, fraction of W_max (0-1)
    W_max     = PAR[1] # Field capacity
    m2        = PAR[2] # exponent of drainage
    Ks        = PAR[3] # Ks parameter of infiltration and drainage
    Nu        = PAR[4] # fraction of drainage verusu interflow
    gamma1    = PAR[5] # coefficient lag-time relationship
    Kc        = PAR[6] # parameter of potential evapotranspiration
    alpha     = PAR[7] # runoff exponent


    delta_T = 24      # input data time step in hour
    dt      = 0.2     # computation time step in hour
    Ks      = Ks*24


    #%  Potential Evapotranspiration parameter
    L=np.array([0.2100,0.2200,0.2300,0.2800,0.3000,0.3100,0.3000,0.2900,0.2700,0.2500,0.2200,0.2000])

    Ka=1.26
    T=TEMPER.values
    EPOT=(T>0)*(Kc*(Ka*L[MESE-1]*(0.46*T+8)-2))/(24/delta_T)

    #% INITIALIZATION

    BF=np.zeros(N)
    QS=np.zeros(N)
    WW=np.zeros(N)
    PERC=np.zeros(N)


    #% MAIN ROUTINE
    P=PIO.values
    #Q=Qobs.values

    W=W_p*W_max
    PIOprec=0
    S=np.nan
    Pcum=0
    IE=0

    for t in range(N):

        IE=P[t]*(W/W_max)**alpha
        E=EPOT[t]*W/W_max
        PERC=Nu*Ks*(W/W_max)**(m2)
        BF[t]=(1-Nu)*Ks*(W/W_max)**(m2)
        W=W+(P[t]-BF[t]-IE-PERC-E)

        # data assimilation with nudging
        #if K>0:
            #if ~np.isnan(Wobs[t]):
                #W=K*(Wobs[t]*W_max)+(1-K)*W


        if W>=W_max:
            SE=W-W_max
            W=W_max
        else:
            SE=0

        QS[t]=IE+SE
        WW[t]=W/W_max

        if t>2:
            PIOprec=np.sum(P[t-3:t])



    WWW=pd.DataFrame(WW, index=data_input.index)
    WWW.columns=['W']
    df2=data_input.join(WWW)


    #% Convolution (GIUH)
    IUH1=IUH_comp(gamma1,Ab,dt,delta_T)*dt
    IUH1=IUH1/np.sum(IUH1)
    IUH2=IUH_NASH(1,0.5*gamma1,Ab,dt,delta_T)*dt
    IUH2=IUH2/np.sum(IUH2);

    QSint=np.interp(np.arange(0,N,dt),np.arange(0,N,1),QS)
    BFint=np.interp(np.arange(0,N,dt),np.arange(0,N,1),BF)



    temp1=np.convolve(IUH1,QSint)
    temp2=np.convolve(IUH2,BFint)

    yy=np.arange(0,N*np.round(1/dt),np.round(1/dt))
    ii=yy.astype(int)

    #Qsim1=temp2[ii]*(Ab*1000./delta_T/3600)
    Qsim=(temp1[ii]+temp2[ii])*(Ab*1000./delta_T/3600)


    te1 = pd.DataFrame(Qsim, index=data_input.index, columns=list('S'))
    Qout=Qobs.copy()
    te2=pd.Series.to_frame(Qout)
    QQ=te1.join(te2)
    QQ.columns=['S','O']
    df3=df2.join(te1)

    #sim_vs_obs = pd.DataFrame({'Qsim': QTOT, 'Qobs': Qobs[0].values}, index=Qobs.index)
    KGE = evaluator(kge, df3['Q'].values, df3 ['S'].values)
    NS = evaluator(nse, df3['Q'].values, df3['S'].values)
    BIAS = evaluator(pbias, df3['Q'].values, df3['S'].values)
    R = evaluator(mare, df3['Q'].values, df3['S'].values)
    RMSE = evaluator(rmse, df3['Q'].values, df3['S'].values)

    Qnan=df3['Q'];
    Qnan[Qnan==0]=np.nan
    df3['Q']=Qnan;
    #% PRINT FIGURE

    if fig>0:
        stringa_per= name+" NSE="+ "%0.3f" % NS+" KGE="+"%0.3f" % KGE[0]+" BIAS="+ "%0.3f" % BIAS+" RMSE="+ "%0.3f" % RMSE+' $ m^3/s$'
        f, ax = plt.subplots(2, sharex=True, figsize=(12, 10))
        ax[0].plot(df3.index, df3['P'].values,label='Rainfall',color='b')
        #ax[0].set_ylim(0,np.max(df3['P'].values)+5)
        ax[0].set_ylabel('Rainfall [mm]', fontsize=16)
        ax2 = ax[0].twinx()
        ax2.plot(df3.index, df3['W'].values,label='Soil Moisture',color='g')
        ax2.set_title(stringa_per,fontsize=20)
        #ax2.set_ylim(0,np.max(df3['W'].values)+0.05)
        ax2.set_ylabel('Relative saturation [-]', fontsize=16)
        ax[0].grid(True)
        ax[0].tick_params(axis='y', labelsize=16)
        ax2.tick_params(axis='y', labelsize=16)
        ax2.legend(loc='upper right', shadow=True)
        ax[0].legend(loc='upper right', shadow=True)

        ax[1].set_ylabel('Rainfall [mm]')
        ax[1].plot(df3.index, df3['Q'].values,label='Qobs',color='g')
        ax[1].plot(df3.index, df3['S'].values,label='Qsim',color='r')
        #ax[1].set_ylim(0,np.max(df3.max())+10)
        #ax[1].set_ylim(0,df3.+10)
        ax[1].set_ylabel('Discharge [$m^3/s$]', fontsize=16)
        ax[1].grid(True)
        ax[1].tick_params(axis='y', labelsize=16)
        ax[1].tick_params(axis='x', labelsize=14)
        ax[1].legend(loc='upper right', shadow=True)
        #plt.legend(loc='lower right')
        f.savefig(name+'.png',dpi=200)

    return KGE[0],df3
#%% MODDEL RUN

##iMPORTANT!!!!NEED TO BE MODIFIED CONSIDERING THAT PERF HAS BEEN SUBSTITUTED BY HYDROEVAL
#if __name__ == '__main__':

 #  name='migi_0406.txt'
#   data_input=pd.read_csv(name,index_col=0,header = None, names = ['P','T','Q'])
#   PAR=np.loadtxt('X_opt_'+name)
#   fig=1

#   QobsQsim,data=MILC(name,data_input,PAR,fig)

#   Wmodel=data['W']

#   ASC=pd.read_csv('ASCAT.csv',index_col=0)

#   # here must match the ASCAT time series with those of the model i.e. ASC and Wmodel

#   QobsQsim,data=MILC(name,data_input,PAR,Ab,fig,ASC,K=0.1)

#   print(QobsQsim.NS())
#   print(QobsQsim.R())
#  print(data)
