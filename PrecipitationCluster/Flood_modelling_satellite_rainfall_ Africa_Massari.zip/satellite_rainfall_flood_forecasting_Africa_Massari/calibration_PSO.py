

def func(PARv):
    global data_in
    n_particles = PARv.shape[0]
    err = np.zeros(n_particles)
    for i in range(n_particles):
        # to change
        out = basin(PARv[i], data_in)
        perf = out['scores']['KGE'][0][0]
        err[i] = 1 - perf
        #
    return err


import pyswarms as ps
bnds1 = (np.array([1, 1, 1, 1,
                          1, 0.1, 0.01, 1e-9,
                          1, 0, 0,  1e-6,
                          0, 0, 0, 0, 0.5]),
                np.array([150, 150, 150, 1000,
                          1000, 0.5, 0.25, 0.25,
                          250, 5, 0.6, 1,
                          0.4, 1, 1, 1,
                          5]))
options = {'c1': 0.5, 'c2': 0.3, 'w': 0.9}

# Call instance of PSO with bounds argument
optimizer = ps.single.GlobalBestPSO(n_particles=30, dimensions=17, options=options, bounds=bnds1)
cost, pos = optimizer.optimize(func, 20)

PARn = pos
np.savetxt('X_opt_' + name+'.txt', PARn)
# run model
