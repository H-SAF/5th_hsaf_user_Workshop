# -*- coding: utf-8 -*-
"""
Created on Mon Dec  7 12:11:24 2020

@author: s.modanesi
"""
from MILc_2 import *
import numpy as np

def func(PARv):
    global d_input, Ab, name
    n_particles = PARv.shape[0]
    err = np.zeros(n_particles)
    for i in range(n_particles):
        KGE,data=MILC(name,d_input,PARv[i],Ab,Wobs=[],K=0,fig=0)
        err[i] = 1 - KGE
    return err
